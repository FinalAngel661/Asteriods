#pragma once


#include "math\mathdef.h"

#include "math\flops.h"
#include "math\vec2.h"
#include "math\vec3.h"
#include "math\mat3.h"
#include "math\aabb.h"
#include "math\hull.h"
#include "math\collision.h"
#include "math\rand.h"