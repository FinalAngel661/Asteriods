#pragma once


// This header has definitions you may want to change
#include "components\compdef.h"

#include "components\Transform.h"
#include "components\Collider.h"
#include "components\Rigidbody.h"
#include "components\Lifetime.h"
#include "components\Sprite.h"
#include "components\Camera.h"
#include "components\Text.h"