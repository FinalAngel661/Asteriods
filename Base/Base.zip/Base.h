#pragma once

#ifndef MAX_HULL_SIZE
#define MAX_HULL_SIZE 6
#endif

#ifndef TRANS_MAX_CHILDREN
#define TRANS_MAX_CHILDREN 6
#endif


#include "base\Maths.h"
#include "base\Components.h"
#include "base\Data.h"